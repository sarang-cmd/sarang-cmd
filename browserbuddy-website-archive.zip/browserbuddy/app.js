(() => {
  'use strict';

  const STORAGE_KEY = 'browserbuddy-prototype-v1';
  const viewNames = {
    today: 'Today',
    focus: 'Focus session',
    library: 'Focus library',
    insights: 'Insights',
    checkin: 'Check-ins',
    settings: 'Settings',
  };

  const exampleVideos = [
    { id: 'basics', title: 'Gas stoichiometry: the basics', channel: 'The Chemistry Classroom', initials: 'CC', views: '248K views', duration: '12:04', kicker: 'CHEMISTRY, SIMPLIFIED', thumb: 'GAS\nSTOICHIOMETRY', art: 'PV = nRT', style: 'thumb-one' },
    { id: 'moles', title: 'Moles, gases & volume explained', channel: 'Study Lab', initials: 'SL', views: '92K views', duration: '09:28', kicker: 'A QUICK GUIDE', thumb: 'MOLES, GAS\n& VOLUME', art: 'H₂', style: 'thumb-two' },
    { id: 'problems', title: 'Solving gas stoichiometry problems', channel: 'Clear Concepts', initials: 'CC', views: '137K views', duration: '15:16', kicker: 'WORKED EXAMPLES', thumb: 'LET’S SOLVE\nIT TOGETHER', art: 'n → V', style: 'thumb-three' },
  ];

  const freshState = () => ({
    goal: 'Finish my gas stoichiometry assignment',
    topic: 'Gas stoichiometry',
    duration: 45,
    due: 'tomorrow',
    strict: true,
    cloud: false,
    remaining: 45 * 60,
    running: false,
    endAt: null,
    reflection: null,
  });

  function readState() {
    const defaults = freshState();
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null');
      if (!saved || typeof saved !== 'object') return defaults;
      return {
        goal: typeof saved.goal === 'string' && saved.goal.trim() ? saved.goal.slice(0, 120) : defaults.goal,
        topic: typeof saved.topic === 'string' && saved.topic.trim() ? saved.topic.slice(0, 80) : defaults.topic,
        duration: [25, 45, 60].includes(saved.duration) ? saved.duration : defaults.duration,
        due: typeof saved.due === 'string' ? saved.due.slice(0, 40) : defaults.due,
        strict: typeof saved.strict === 'boolean' ? saved.strict : defaults.strict,
        cloud: typeof saved.cloud === 'boolean' ? saved.cloud : defaults.cloud,
        remaining: Number.isFinite(saved.remaining) ? Math.max(0, Math.min(3600, saved.remaining)) : defaults.remaining,
        running: saved.running === true && Number.isFinite(saved.endAt),
        endAt: Number.isFinite(saved.endAt) ? saved.endAt : null,
        reflection: saved.reflection && typeof saved.reflection === 'object' ? saved.reflection : null,
      };
    } catch (_) {
      return defaults;
    }
  }

  let state = readState();
  let editingReflection = false;
  let toastTimeout;
  let storageWarningShown = false;

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (_) {
      if (!storageWarningShown) {
        storageWarningShown = true;
        showToast('Browser storage is unavailable, so your demo choices won’t be saved.');
      }
    }
  }

  function showToast(message) {
    const toast = document.querySelector('.toast');
    toast.textContent = message;
    toast.hidden = false;
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => { toast.hidden = true; }, 3800);
  }

  function dueLabel() {
    const due = state.due.trim();
    if (!due) return 'No deadline set';
    return /^due\b/i.test(due) ? due : `Due ${due}`;
  }

  function remainingNow() {
    return state.running ? Math.max(0, Math.ceil((state.endAt - Date.now()) / 1000)) : state.remaining;
  }

  function formatTime(seconds) {
    const safe = Math.max(0, Math.floor(seconds));
    return `${String(Math.floor(safe / 60)).padStart(2, '0')}:${String(safe % 60).padStart(2, '0')}`;
  }

  function renderTimer() {
    const remaining = remainingNow();
    if (state.running && remaining === 0) {
      state.running = false;
      state.remaining = 0;
      state.endAt = null;
      saveState();
      showToast('Your demo focus session is complete. Nice work showing up.');
    }
    document.querySelectorAll('[data-timer]').forEach(el => { el.textContent = formatTime(remaining); });
    const action = state.running ? 'Pause timer' : remaining === state.duration * 60 ? 'Start focus session' : remaining === 0 ? 'Start again' : 'Resume timer';
    document.querySelectorAll('[data-session-action]').forEach(el => { el.textContent = action; });
    document.querySelectorAll('[data-session-toggle] .button-icon use').forEach(el => { el.setAttribute('href', state.running ? '#i-pause' : '#i-play'); });
    document.querySelectorAll('[data-timer-status]').forEach(el => { el.textContent = state.running ? 'FOCUSING · DEMO' : remaining === 0 ? 'SESSION COMPLETE' : remaining < state.duration * 60 ? 'PAUSED · DEMO' : 'READY WHEN YOU ARE'; });
    document.querySelectorAll('[data-session-description]').forEach(el => { el.textContent = state.running ? 'Demo timer running. No websites are blocked.' : 'Demo only. No websites are blocked.'; });
  }

  function renderReflection() {
    const complete = Boolean(state.reflection) && !editingReflection;
    document.getElementById('reflection-form-card').hidden = complete;
    document.getElementById('reflection-complete').hidden = !complete;
    document.querySelectorAll('[data-checkin-count]').forEach(el => { el.hidden = Boolean(state.reflection); });
    document.querySelectorAll('[data-checkin-action]').forEach(el => { el.textContent = state.reflection ? 'View your reflection' : 'Take a 1-minute check-in'; });
    const form = document.getElementById('checkin-form');
    const saved = state.reflection;
    form.querySelectorAll('input[name="intended"]').forEach(input => { input.checked = Boolean(saved && input.value === saved.intended); });
    form.elements.note.value = saved && typeof saved.note === 'string' ? saved.note : '';
    form.elements.plan.value = saved && typeof saved.plan === 'string' ? saved.plan : '';
  }

  function renderState() {
    document.querySelectorAll('[data-goal]').forEach(el => { el.textContent = state.goal; });
    document.querySelectorAll('[data-topic]').forEach(el => { el.textContent = state.topic; });
    document.querySelectorAll('[data-duration]').forEach(el => { el.textContent = `${state.duration} minutes`; });
    document.querySelectorAll('[data-due]').forEach(el => { el.textContent = dueLabel(); });
    document.querySelectorAll('[data-strict-label]').forEach(el => { el.textContent = state.strict ? 'STRICT MODE SELECTED' : 'GENTLE MODE SELECTED'; });
    document.querySelectorAll('[data-strict-sentence]').forEach(el => { el.textContent = state.strict ? 'Strict mode selected.' : 'Gentle mode selected.'; });
    document.querySelectorAll('[data-setting]').forEach(el => { el.setAttribute('aria-checked', String(Boolean(state[el.dataset.setting]))); });
    renderTimer();
    renderReflection();
  }

  function showView(name, updateHash = true) {
    const selected = Object.hasOwn(viewNames, name) ? name : 'today';
    document.querySelectorAll('[data-view]').forEach(el => { el.hidden = el.dataset.view !== selected; });
    document.querySelectorAll('.nav-item[data-nav]').forEach(el => {
      const active = el.dataset.nav === selected;
      el.classList.toggle('active', active);
      if (active) el.setAttribute('aria-current', 'page');
      else el.removeAttribute('aria-current');
    });
    document.getElementById('breadcrumb-current').textContent = viewNames[selected];
    if (updateHash) {
      try { history.replaceState(null, '', `#${selected}`); } catch (_) { /* The prototype also works when opened from disk. */ }
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
  }

  function openDialog(id) {
    const dialog = document.getElementById(id);
    if (!dialog || dialog.open) return;
    document.querySelectorAll('dialog[open]').forEach(open => open.close());
    dialog.showModal();
  }

  function openIntention() {
    const form = document.getElementById('intention-form');
    form.elements.goal.value = state.goal;
    form.elements.topic.value = state.topic;
    form.elements.duration.value = String(state.duration);
    form.elements.due.value = state.due;
    form.elements.goal.setCustomValidity('');
    form.elements.topic.setCustomValidity('');
    openDialog('intention-dialog');
  }

  function toggleSession() {
    if (state.running) {
      state.remaining = remainingNow();
      state.running = false;
      state.endAt = null;
      showToast('Demo timer paused.');
    } else {
      if (state.remaining <= 0) state.remaining = state.duration * 60;
      state.running = true;
      state.endAt = Date.now() + state.remaining * 1000;
      showToast('Demo timer started. No websites are being blocked.');
    }
    saveState();
    renderTimer();
  }

  function resetTimer() {
    state.running = false;
    state.endAt = null;
    state.remaining = state.duration * 60;
    saveState();
    renderTimer();
  }

  function makeIcon(symbol) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'icon');
    svg.setAttribute('aria-hidden', 'true');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', `#${symbol}`);
    svg.appendChild(use);
    return svg;
  }

  function videoCard(video) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'video-card';
    card.dataset.video = video.id;
    card.setAttribute('aria-label', `Preview example video: ${video.title}, ${video.channel}, ${video.views}`);

    const thumb = document.createElement('span');
    thumb.className = `video-thumb ${video.style}`;
    const kicker = document.createElement('span');
    kicker.className = 'thumb-kicker';
    kicker.textContent = video.kicker;
    const title = document.createElement('span');
    title.className = 'thumb-title';
    title.textContent = video.thumb;
    const art = document.createElement('span');
    art.className = 'thumb-art';
    art.setAttribute('aria-hidden', 'true');
    art.textContent = video.art;
    const play = document.createElement('span');
    play.className = 'thumb-play';
    play.appendChild(makeIcon('i-play'));
    const duration = document.createElement('span');
    duration.className = 'thumb-duration';
    duration.textContent = video.duration;
    thumb.append(kicker, title, art, play, duration);

    const body = document.createElement('span');
    body.className = 'video-body';
    const avatar = document.createElement('span');
    avatar.className = 'video-channel-icon';
    avatar.setAttribute('aria-hidden', 'true');
    avatar.textContent = video.initials;
    const copy = document.createElement('span');
    copy.className = 'video-copy';
    const heading = document.createElement('strong');
    heading.textContent = video.title;
    const metadata = document.createElement('p');
    metadata.textContent = `${video.channel} · ${video.views}`;
    copy.append(heading, metadata);
    body.append(avatar, copy);
    card.append(thumb, body);
    return card;
  }

  function renderVideos(query = '') {
    const home = document.getElementById('home-videos');
    const library = document.getElementById('library-videos');
    home.replaceChildren(...exampleVideos.map(videoCard));
    const normalized = query.trim().toLocaleLowerCase();
    const matches = exampleVideos.filter(video => `${video.title} ${video.channel} ${video.kicker}`.toLocaleLowerCase().includes(normalized));
    library.replaceChildren(...matches.map(videoCard));
    document.getElementById('no-videos').hidden = matches.length > 0;
  }

  document.addEventListener('click', event => {
    const nav = event.target.closest('[data-nav]');
    if (nav) {
      if (nav.tagName === 'A' && (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button !== 0)) return;
      event.preventDefault();
      if (nav.dataset.nav === 'checkin') editingReflection = false;
      renderReflection();
      showView(nav.dataset.nav);
      return;
    }
    const intention = event.target.closest('[data-open-intention]');
    if (intention) { openIntention(); return; }
    const opener = event.target.closest('[data-open]');
    if (opener) { openDialog(opener.dataset.open); return; }
    const closer = event.target.closest('[data-close]');
    if (closer) { closer.closest('dialog').close(); return; }
    const interrupt = event.target.closest('[data-interrupt-choice]');
    if (interrupt) {
      interrupt.closest('dialog').close();
      showToast(interrupt.dataset.interruptChoice === 'return' ? 'In the real product, this could take you back to your task.' : 'In the real product, you could choose to continue.');
      return;
    }
    const toggle = event.target.closest('[data-session-toggle]');
    if (toggle) { toggleSession(); return; }
    const end = event.target.closest('[data-end-session]');
    if (end) { resetTimer(); showToast('Demo timer reset.'); return; }
    const setting = event.target.closest('[data-setting]');
    if (setting) {
      const key = setting.dataset.setting;
      if (key === 'strict' || key === 'cloud') {
        state[key] = !state[key];
        saveState();
        renderState();
        showToast(key === 'cloud' ? 'Demo preference updated. No data is sent.' : 'Demo focus preference updated. No sites are blocked.');
      }
      return;
    }
    const video = event.target.closest('[data-video]');
    if (video) {
      const example = exampleVideos.find(item => item.id === video.dataset.video);
      if (example) {
        document.getElementById('video-dialog-title').textContent = example.title;
        document.getElementById('video-dialog-meta').textContent = `${example.channel} · ${example.views} · ${example.duration} (illustrative)`;
        openDialog('video-dialog');
      }
    }
  });

  document.querySelectorAll('dialog').forEach(dialog => {
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  });

  document.getElementById('intention-form').addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    const goal = form.elements.goal.value.trim();
    const topic = form.elements.topic.value.trim();
    if (!goal || !topic) {
      const invalid = !goal ? form.elements.goal : form.elements.topic;
      invalid.setCustomValidity('Please add a little detail.');
      invalid.reportValidity();
      return;
    }
    const duration = Number(form.elements.duration.value);
    state.goal = goal.slice(0, 120);
    state.topic = topic.slice(0, 80);
    state.duration = [25, 45, 60].includes(duration) ? duration : 45;
    state.due = form.elements.due.value.trim().slice(0, 40);
    state.running = false;
    state.endAt = null;
    state.remaining = state.duration * 60;
    saveState();
    renderState();
    document.getElementById('intention-dialog').close();
    showToast('Intention saved in this browser.');
  });
  document.querySelectorAll('#intention-form input').forEach(input => input.addEventListener('input', () => input.setCustomValidity('')));

  document.getElementById('checkin-form').addEventListener('submit', event => {
    event.preventDefault();
    const form = event.currentTarget;
    const intended = form.querySelector('input[name="intended"]:checked');
    if (!intended) return;
    state.reflection = { intended: intended.value, note: form.elements.note.value.trim().slice(0, 1000), plan: form.elements.plan.value.trim().slice(0, 300) };
    editingReflection = false;
    saveState();
    renderReflection();
    showToast('Reflection saved in this browser.');
  });
  document.getElementById('edit-reflection').addEventListener('click', () => { editingReflection = true; renderReflection(); });
  document.getElementById('video-search').addEventListener('input', event => renderVideos(event.target.value));
  document.getElementById('confirm-reset').addEventListener('click', () => {
    try { localStorage.removeItem(STORAGE_KEY); } catch (_) { /* In-memory state is still reset. */ }
    state = freshState();
    editingReflection = false;
    document.getElementById('video-search').value = '';
    renderState();
    renderVideos();
    document.getElementById('reset-dialog').close();
    showToast('Demo reset. You’re back to the example data.');
  });
  window.addEventListener('hashchange', () => showView(location.hash.slice(1), false));

  const date = new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' }).format(new Date()).toLocaleUpperCase();
  document.querySelector('[data-today-date]').textContent = date;
  renderVideos();
  renderState();
  showView(location.hash.slice(1) || 'today', false);
  setInterval(renderTimer, 1000);
})();
